SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `competitions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_type` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `competition_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visible_as_tile` tinyint(1) NOT NULL,
  `tile_order` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `year` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_starts_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `registration_starts_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `registration_stops_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `registration_ends_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `draft` tinyint(1) NOT NULL,
  `schedule_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `event_competitions` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `competition_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `event_partners` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `migration_versions` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `migration_versions` VALUES
('20180330042731'),
('20180409221804'),
('20180425154134'),
('20180502055108'),
('20180503210523'),
('20180504215726'),
('20180505092306'),
('20180505144017'),
('20180508185144'),
('20180509173017'),
('20180516164941'),
('20180516200950'),
('20180516225049'),
('20180517231530'),
('20180520154832'),
('20180522130338'),
('20180525152733'),
('20180605221203');

CREATE TABLE `registration_constructions` (
  `id` int(11) NOT NULL,
  `team_id` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `registration_constructions_competitions` (
  `construction_id` int(11) NOT NULL,
  `competition_id` int(11) NOT NULL,
  `presence_checked_at` int(11) DEFAULT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `tech_validated_at` int(11) DEFAULT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `registration_constructions_creators` (
  `construction_id` int(11) NOT NULL,
  `creator_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `registration_information` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `type` smallint(6) NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `registration_members` (
  `id` int(11) NOT NULL,
  `team_id` int(11) DEFAULT NULL,
  `forename` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shirt_type` smallint(6) NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `presence_checked_at` int(11) DEFAULT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `shirt_given_out_at` int(11) DEFAULT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `registration_members_hackathon` (
  `id` int(11) NOT NULL,
  `team_id` int(11) DEFAULT NULL,
  `forename` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` smallint(6) NOT NULL,
  `shirt_type` smallint(6) NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `presence_checked_at` int(11) DEFAULT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `shirt_given_out_at` int(11) DEFAULT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `registration_surveys` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `type` smallint(6) NOT NULL,
  `survey` json NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `created_by_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `registration_teams` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scientific_organization` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `registration_teams_hackathon` (
  `id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `why_you` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `experience` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `captain_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `rules` (
  `id` int(11) NOT NULL,
  `event_competition_id` int(11) DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `storage_files` (
  `id` int(11) NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `forename` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  `roles` json NOT NULL,
  `created_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `last_login_at` int(11) DEFAULT NULL COMMENT '(DC2Type:timestamp_immutable)',
  `token` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_requested_at` int(11) NOT NULL COMMENT '(DC2Type:timestamp_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


ALTER TABLE `competitions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_A7DD463DFE54D947` (`group_id`);

ALTER TABLE `competition_groups`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_5387574AA40BC2D5` (`schedule_id`);

ALTER TABLE `event_competitions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_4ACE4CCE71F7E88B` (`event_id`),
  ADD KEY `IDX_4ACE4CCE7B39D312` (`competition_id`);

ALTER TABLE `event_partners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_A907B8B471F7E88B` (`event_id`),
  ADD KEY `IDX_A907B8B493CB796C` (`file_id`);

ALTER TABLE `migration_versions`
  ADD PRIMARY KEY (`version`);

ALTER TABLE `registration_constructions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_2D77EAC75E237E06296CD8AE` (`name`,`team_id`),
  ADD KEY `IDX_2D77EAC7296CD8AE` (`team_id`);

ALTER TABLE `registration_constructions_competitions`
  ADD PRIMARY KEY (`construction_id`,`competition_id`),
  ADD KEY `IDX_520AB2E9CF48117A` (`construction_id`),
  ADD KEY `IDX_520AB2E97B39D312` (`competition_id`);

ALTER TABLE `registration_constructions_creators`
  ADD PRIMARY KEY (`construction_id`,`creator_id`),
  ADD KEY `IDX_BD821306CF48117A` (`construction_id`),
  ADD KEY `IDX_BD82130661220EA6` (`creator_id`);

ALTER TABLE `registration_information`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_6BF6BB2671F7E88B` (`event_id`);

ALTER TABLE `registration_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5D18759296CD8AE` (`team_id`);

ALTER TABLE `registration_members_hackathon`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_191CCE73296CD8AE` (`team_id`);

ALTER TABLE `registration_surveys`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_EFD97B018CDE572971F7E88BB03A8386` (`type`,`event_id`,`created_by_id`),
  ADD KEY `IDX_EFD97B0171F7E88B` (`event_id`),
  ADD KEY `IDX_EFD97B01B03A8386` (`created_by_id`);

ALTER TABLE `registration_teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_196882B0772E836A71F7E88B` (`identifier`,`event_id`),
  ADD KEY `IDX_196882B071F7E88B` (`event_id`),
  ADD KEY `IDX_196882B0B03A8386` (`created_by_id`);

ALTER TABLE `registration_teams_hackathon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_F1BB96B15E237E0671F7E88B` (`name`,`event_id`),
  ADD UNIQUE KEY `UNIQ_F1BB96B13346729B` (`captain_id`),
  ADD KEY `IDX_F1BB96B171F7E88B` (`event_id`),
  ADD KEY `IDX_F1BB96B1B03A8386` (`created_by_id`);

ALTER TABLE `rules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_899A993CA47D6561` (`event_competition_id`);

ALTER TABLE `storage_files`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_1483A5E9E7927C74` (`email`);


ALTER TABLE `competitions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `competition_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `event_competitions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `event_partners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `registration_constructions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `registration_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `registration_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `registration_members_hackathon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `registration_surveys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `registration_teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `registration_teams_hackathon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `storage_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `competitions`
  ADD CONSTRAINT `FK_A7DD463DFE54D947` FOREIGN KEY (`group_id`) REFERENCES `competition_groups` (`id`);

ALTER TABLE `events`
  ADD CONSTRAINT `FK_5387574AA40BC2D5` FOREIGN KEY (`schedule_id`) REFERENCES `storage_files` (`id`);

ALTER TABLE `event_competitions`
  ADD CONSTRAINT `FK_4ACE4CCE71F7E88B` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  ADD CONSTRAINT `FK_4ACE4CCE7B39D312` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`id`);

ALTER TABLE `event_partners`
  ADD CONSTRAINT `FK_A907B8B471F7E88B` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  ADD CONSTRAINT `FK_A907B8B493CB796C` FOREIGN KEY (`file_id`) REFERENCES `storage_files` (`id`);

ALTER TABLE `registration_constructions`
  ADD CONSTRAINT `FK_2D77EAC7296CD8AE` FOREIGN KEY (`team_id`) REFERENCES `registration_teams` (`id`);

ALTER TABLE `registration_constructions_competitions`
  ADD CONSTRAINT `FK_520AB2E97B39D312` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`id`),
  ADD CONSTRAINT `FK_520AB2E9CF48117A` FOREIGN KEY (`construction_id`) REFERENCES `registration_constructions` (`id`);

ALTER TABLE `registration_constructions_creators`
  ADD CONSTRAINT `FK_BD82130661220EA6` FOREIGN KEY (`creator_id`) REFERENCES `registration_members` (`id`),
  ADD CONSTRAINT `FK_BD821306CF48117A` FOREIGN KEY (`construction_id`) REFERENCES `registration_constructions` (`id`);

ALTER TABLE `registration_information`
  ADD CONSTRAINT `FK_6BF6BB2671F7E88B` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`);

ALTER TABLE `registration_members`
  ADD CONSTRAINT `FK_5D18759296CD8AE` FOREIGN KEY (`team_id`) REFERENCES `registration_teams` (`id`);

ALTER TABLE `registration_members_hackathon`
  ADD CONSTRAINT `FK_191CCE73296CD8AE` FOREIGN KEY (`team_id`) REFERENCES `registration_teams_hackathon` (`id`);

ALTER TABLE `registration_surveys`
  ADD CONSTRAINT `FK_EFD97B0171F7E88B` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  ADD CONSTRAINT `FK_EFD97B01B03A8386` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`);

ALTER TABLE `registration_teams`
  ADD CONSTRAINT `FK_196882B071F7E88B` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  ADD CONSTRAINT `FK_196882B0B03A8386` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`);

ALTER TABLE `registration_teams_hackathon`
  ADD CONSTRAINT `FK_F1BB96B13346729B` FOREIGN KEY (`captain_id`) REFERENCES `registration_members_hackathon` (`id`),
  ADD CONSTRAINT `FK_F1BB96B171F7E88B` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`),
  ADD CONSTRAINT `FK_F1BB96B1B03A8386` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`);

ALTER TABLE `rules`
  ADD CONSTRAINT `FK_899A993CA47D6561` FOREIGN KEY (`event_competition_id`) REFERENCES `event_competitions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
